import subprocess
from PIL import Image, ImageEnhance

# Paso 1: Mejorar el contraste
img = Image.open('img/input.png')
enhancer = ImageEnhance.Contrast(img)
img = enhancer.enhance(2.0)  # Ajusta el valor según sea necesario
img.save('output/img/input_contrast.png')

# Paso 3: Ejecutar Kraken con subprocess
kraken_command = [
    'kraken', '-i', 'output/img/input_contrast.png', 'output/txt/test.txt', 'binarize', 'segment', 'ocr', '--model', 'kraken/models/McCATMuS_nfd_nofix_V1.mlmodel'
]

# Ejecutar el comando Kraken
subprocess.run(kraken_command)