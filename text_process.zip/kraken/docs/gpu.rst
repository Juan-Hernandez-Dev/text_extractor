.. _gpu:

GPU Acceleration
================

The latest version of kraken uses a new pytorch backend which enables GPU
acceleration both for training and recognition. Apart from a compatible Nvidia
GPU, CUDA and cuDNN have to be installed so pytorch can run computation on it.


