"""
entry point for kraken functionality
"""
